﻿
namespace Dnp.Data.Objects
{
    public interface IObjectCreated
    {
        bool IsNew { get; }
    }
}
