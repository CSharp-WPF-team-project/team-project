﻿
namespace Dnp.Data.Objects
{
    public interface ISimplePrimaryKeyEquatable
    {
        bool KeyEquals(object keyObject);
    }
}
