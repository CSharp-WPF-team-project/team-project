﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Notice.Model
{
    public class KakaoData
    {

        public static string userToken;//유저토큰
        public static string accessToken;//엑세스토큰
        public static string userNickName;//사용자 이름

    }
}
