﻿
namespace Dnp.Data.Objects
{
    public interface ICloneable<T>
    {
        T Clone();
    }
}
