﻿namespace Dnp.Data.Metadata.Elements
{
    public sealed class ScalarProperty
    {
        public string Name { get; set; }

        public string ColumnName { get; set; }
    }
}
