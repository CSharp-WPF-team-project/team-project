﻿using System.Windows.Controls;


namespace Notice.View
{
    public partial class Home : Page
    {
        public Home()
        {
            InitializeComponent();
        }
    }
}
