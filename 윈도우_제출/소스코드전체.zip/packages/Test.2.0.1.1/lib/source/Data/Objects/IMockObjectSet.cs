﻿
namespace Dnp.Data.Objects
{
    public interface IMockObjectSet
    {
        void AddObject(object entity);
        void DeleteObject(object entity);
    }
}
