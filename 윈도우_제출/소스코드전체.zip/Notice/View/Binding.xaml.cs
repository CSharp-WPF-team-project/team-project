﻿using System.Windows;
using System.Windows.Controls;

namespace Notice.View
{
    /// <summary>
    /// Binding.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Binding : Page
    {
        public Binding()
        {
            InitializeComponent();
        }
    }
}
