﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace Notice.View
{
	/// <summary>
	/// Notice.xaml에 대한 상호 작용 논리
	/// </summary>
	public partial class Notice : Page
	{
		

		//int grade = 0;
		public Notice()
		{
			
			InitializeComponent();

		}

    }
}
