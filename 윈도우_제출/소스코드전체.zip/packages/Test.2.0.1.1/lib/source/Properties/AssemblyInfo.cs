﻿using System;
using System.Reflection;
using Dnp.Properties;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Windows")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("Windows")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion( CurrentVersion.Version )]
[assembly: AssemblyFileVersion(CurrentVersion.Version)]


namespace Dnp.Properties
{
    public class CurrentVersion
    {
        public const string Version = "2.0.1";
    }
}